
╔════════════════════════════════════════════════════════════╗
║                   YOUR FILES ARE ENCRYPTED                 ║
╚════════════════════════════════════════════════════════════╝

All your important files have been encrypted with military-grade
encryption.

WHAT HAPPENED?
Your files were encrypted using a strong cryptographic algorithm.
Without the decryption key, recovery is mathematically impossible.


    
